package it.mobilalab.base_project_3

import android.R.attr
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas


class Wall(
    gameView: GameView,
    brickBmp: Bitmap,
    spriteColumns: Int,
    horizontalNumOfBrick: Int,
    verticalNumOfBrick: Int
) {

    private var wall = arrayListOf<Brick>()
    private var xUnits = 0
    private var yUnits = 0
    private var spriteRows = 1

    init {
        xUnits = horizontalNumOfBrick
        yUnits = verticalNumOfBrick

        //Creates a Wall
        var x_brick: Int
        var y_brick: Int

        for (i in 0 until xUnits) {
            x_brick = i * brickBmp.width / spriteColumns
            for (j in 0 until yUnits) {
                y_brick = j * brickBmp.height / spriteRows
                wall.add(
                    Brick(
                        gameView,
                        brickBmp,
                        spriteRows,
                        spriteColumns,
                        attr.x + x_brick,
                        attr.y + y_brick
                    )
                )
            }
        }
    }

    @SuppressLint("WrongCall")
    fun onDraw(canvas: Canvas?) {
        for (brick in wall) {
            if (canvas != null) {
                brick.onDraw(canvas)
            }
        }
    }

}
