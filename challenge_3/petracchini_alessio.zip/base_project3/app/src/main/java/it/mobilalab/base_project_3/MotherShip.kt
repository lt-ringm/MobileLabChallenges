package it.mobilalab.base_project_3

import android.graphics.Bitmap
import it.mobilalab.base_project_3.GameView
import it.mobilalab.base_project_3.InvaderSpaceShip

class MotherShip(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x: Int,
    y: Int,
    xSpeed: Int,
    ySpeed: Int,
    points: Int
): InvaderSpaceShip(gameView, bmp, bmpRows, bmpColumns, x, y, points) {

    init {
        this.x = x
        this.y = y
        this.xSpeed = xSpeed
        this.ySpeed = ySpeed
        this.points = points
    }

    override fun update() {
        if (x >= gameView.width - width - xSpeed || x + xSpeed <= 0) {
            xSpeed = -xSpeed
            points = if (points == 0) 0 else points - 10
        } else {
            x = x + xSpeed
        }
        currentFrameColumn = getNextAnimationColumn()
    }

    override fun getNextAnimationRow(): Int {
        return 0
    }

    override fun getNextAnimationColumn(): Int {
        return ++currentFrameColumn % bmpColumns
    }

    override fun moveDown(stepDown: Int) {}

}