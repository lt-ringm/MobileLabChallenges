package it.mobilalab.base_project_3

import android.content.Context
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

class GoodSpaceShip(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    context: Context
): Sprite(gameView, bmp, bmpRows, bmpColumns) {

    init {
        //Depends on each type of sprite
        x = (gameView.width - width) / 2
        y = gameView.height - height
        xSpeed = 0
        ySpeed = 0
    }

    fun update(xs:Int, ys:Int) {
        if (alive) {
            y += ys
            x += xs
        }
    }
}
