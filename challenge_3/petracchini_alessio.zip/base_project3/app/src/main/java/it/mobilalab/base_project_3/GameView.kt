package it.mobilalab.base_project_3

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.room.Room
import it.space_invaders_kotlin.Shoot


class GameView(context: Context, activity: MainActivity, xs:Int, ys:Int) : SurfaceView(context) {

    private var activity: MainActivity
    private var context: Context

    var shipName = ""
    private var gameLoopThread: GameLoopThread
    private lateinit var invaderSpaceFleet: InvaderSpaceFleet
    private lateinit var explosion: Explosion
    private lateinit var goodSpaceShip: GoodSpaceShip
    private lateinit var goodSpaceShipShoot: Shoot
    private lateinit var invaderSpaceShipShoot: Shoot
    private lateinit var shield: Shield
    private lateinit var bmpExplosion: Bitmap
    private lateinit var bmpGoodShoot: Bitmap
    private lateinit var bmpInvaderShoot: Bitmap
    private lateinit var bmpBrick: Bitmap

    private var firstStart = true
    private var lastClick: Long = 0

    private var gameState = 1   //1 = play; 2 = game over
    private var x: Int = xs
    private var y: Int = ys

    //sound
    private var soundPool: SoundPool? = null
    private var mPlayer: MediaPlayer? = null
    private var soundId = 0

    init {
        this.activity = activity
        this.context = context

        //background music
        if (mPlayer == null) {
            mPlayer = MediaPlayer.create(context, R.raw.music)
            mPlayer?.setLooping(true)
        }

        //load sound
        soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        soundId = soundPool!!.load(getContext(), R.raw.puaj, 1)

        gameLoopThread = GameLoopThread(this)

        holder.addCallback(object: SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
               bmpExplosion = BitmapFactory.decodeResource(getResources(), R.drawable.explosion);
               bmpGoodShoot = BitmapFactory.decodeResource(getResources(), R.drawable.goodspaceshipshoot);
               bmpInvaderShoot = BitmapFactory.decodeResource(getResources(), R.drawable.invaderspaceshipshoot);
               bmpBrick = BitmapFactory.decodeResource(getResources(), R.drawable.brick);
                createGoodSpaceShip(shipName)
                createInvaderSpaceFleet()
                createGoodSpaceShipShoot(false)
                createInvaderSpaceShipShoot(false)
                createExplosion(false,false)
                createShield()

                gameLoopThread.setRunning(true)
                if(firstStart){
                    gameLoopThread.start()
                    firstStart = false
                }
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                var retry = true
                gameLoopThread.setRunning(false)
                while (retry) {
                    try {
                        gameLoopThread.join()
                        retry = false
                    } catch (e: InterruptedException) {
                    }
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            }
        })
    }

    val db = Room.databaseBuilder(this.context,AppDatabase::class.java, "data-app").build()
    val chartDao = db.chartDao();

    // Creates a good ship
    private fun createGoodSpaceShip(shipName: String) {
        val bmp: Bitmap
        when (shipName) {
            "pink_asteroid" -> bmp = BitmapFactory.decodeResource(resources, R.drawable.pink_asteroid_spaceship)
            "asteroid" -> bmp = BitmapFactory.decodeResource(resources, R.drawable.asteroid_spaceship)
            else -> bmp = BitmapFactory.decodeResource(resources, R.drawable.goodspaceship)
        }
        goodSpaceShip = GoodSpaceShip(this, bmp, 1, 13, context)
    }

    //creates an invader ship
    fun createInvaderSpaceFleet() {
        val landingHeight = goodSpaceShip.height
        invaderSpaceFleet = InvaderSpaceFleet(this, this.height)
    }

    fun createGoodSpaceShipShoot(alive: Boolean) {
        val spriteColumns = 2
        val spriteRows = 1
        val x: Int =
            goodSpaceShip.x + goodSpaceShip.width / 2 - bmpGoodShoot.width / spriteColumns / 2
        val y: Int = goodSpaceShip.y
        val xSpeed: Int = goodSpaceShip.xSpeed
        goodSpaceShipShoot =
            Shoot(this, bmpGoodShoot, spriteRows, spriteColumns, x, y, xSpeed, false, alive)
    }

    fun createInvaderSpaceShipShoot(alive: Boolean) {
        val spriteColumns = 9
        val spriteRows = 1
        val shooterShip: Sprite = invaderSpaceFleet.getShooter()!!
        val x =
            shooterShip.x + shooterShip.width / 2 - bmpInvaderShoot.width / spriteColumns / 2
        val y = shooterShip.y
        invaderSpaceShipShoot =
            Shoot(this, bmpInvaderShoot, spriteRows, spriteColumns, x, y, 0, true, alive)
    }

    fun createExplosion(alive: Boolean, invaderShip: Boolean) {
        val spriteColumns = 25
        val spriteRows = 1
        val x: Int
        val y: Int
        if (invaderShip) {
            x =
                goodSpaceShipShoot.x + goodSpaceShipShoot.width / 2 - bmpExplosion.width / spriteColumns / 2
            y = goodSpaceShipShoot.y - goodSpaceShipShoot.height / 2
        } else {
            x = goodSpaceShip.x
            y = goodSpaceShip.y
        }
        explosion = Explosion(this, bmpExplosion, spriteRows, spriteColumns, x, y, alive)
    }

    fun createShield() {
        val horizontalNumOfBrick = 8
        val verticalNumOfBrick = 4
        val spriteColumns = 4
        val numberOfWalls = 3

        val x_ini = 0
        val y_ini = goodSpaceShip.y - bmpBrick.width - 10

        for (i in 0 until numberOfWalls) {
            shield = Shield(
                this,
                bmpBrick,
                spriteColumns,
                horizontalNumOfBrick,
                verticalNumOfBrick,
                x_ini,
                y_ini
            )
        }
    }

    fun drawGameScreen(canvas: Canvas) {
        if (goodSpaceShip.alive) {
            goodSpaceShip.onDraw(canvas)
        }
        invaderSpaceFleet.onDraw(canvas)
        if (goodSpaceShipShoot.alive) {
            goodSpaceShipShoot.onDraw(canvas)
        }
        if (invaderSpaceShipShoot.alive) {
            invaderSpaceShipShoot.onDraw(canvas)
        } else {
            if (Math.random() < 0.1) {
                createInvaderSpaceShipShoot(true)
            }
        }
        if (shield.isAlive()) {
            shield.onDraw(canvas)
        }
        if (explosion.alive) {
            explosion.onDraw(canvas)
        }

        //If an invader arrives or if the ship is destroyed... Game Over
        if (invaderSpaceFleet.invaderArrive() || !goodSpaceShip.alive) {
            gameState = 2
        }
    }

    @SuppressLint("WrongCall")
    public override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        when (gameState) {
            1 -> drawGameScreen(canvas)
            2 -> {
                chartDao.insertAll(Chart(1,"ciaouser", "45"), Chart(2,"okuser", "60"))
            }
            else -> gameState = 1
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (System.currentTimeMillis() - lastClick > 300) {
            lastClick = System.currentTimeMillis()
            synchronized(holder) {
                when (gameState) {
                    1 -> if (!goodSpaceShipShoot.alive) {
                        createGoodSpaceShipShoot(true)
                        soundPool!!.play(soundId, 1f, 1f, 0, 0, 1f)
                    }

                    2 -> gameState = 3

                    3 -> {
                        gameState = 1
                        createGoodSpaceShip(shipName)
                        createInvaderSpaceFleet()
                        createShield()
                        createGoodSpaceShipShoot(false)
                        createInvaderSpaceShipShoot(false)
                    }

                    else -> gameState = 1
                }
            }
        }
        return true
    }

    // Music functions
    fun startMusicPlayer() {
        mPlayer!!.start()
    }

    fun pauseMusicPlayer() {
        mPlayer!!.pause()
    }

    fun releaseMusicPlayer() {
        mPlayer!!.release()
        soundPool!!.release()
    }

    fun stopMusicPlayer() {
        mPlayer!!.stop()
    }

    fun update(xs: Int, ys: Int) {
        goodSpaceShip!!.update(xs, ys)
    }

    fun returnX (): Int {
        return x
    }

    fun returnY (): Int {
        return y
    }

}

