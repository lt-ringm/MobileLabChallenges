package it.mobilalab.base_project_3

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect

open class Sprite (gameView: GameView, bmp: Bitmap, bmpRows: Int, bmpColumns: Int) {

    protected var bmpRows = 2
    protected var bmpColumns = 12
    protected var src: Rect
    protected var dst: Rect

    protected var gameView: GameView
    protected var bmp: Bitmap
    var x = 0
    var y = 0
    var xSpeed = 0
    var ySpeed = 0
    protected var currentFrameColumn = 0
    protected var currentFrameRow = 0
    var width = 0
    var height = 0
    var alive = false

    init {
        //Depends on each type of sprite
        this.bmpRows = bmpRows
        this.bmpColumns = bmpColumns

        //same for all sprites
        width = bmp.width / bmpColumns
        height = bmp.height / bmpRows
        this.gameView = gameView
        this.bmp = bmp

        // Initialize Rect
        val srcX = currentFrameColumn * width
        val srcY = currentFrameRow * height
        src = Rect(srcX, srcY, srcX + width, srcY + height)
        dst = Rect(x, y, x + width, y + height)

        //Depends on each type of sprite
        //Random rnd = new Random();
        x = 30 //rnd.nextInt(gameView.getWidth() - width);
        y = 30 //rnd.nextInt(gameView.getHeight() - height);

        xSpeed = 0
        ySpeed = 0
        alive = true
    }

    protected open fun update() {
        if (x >= gameView.width - width - xSpeed || x + xSpeed <= 0) {
            xSpeed = -xSpeed
        }
        x = x + xSpeed
        if (y >= gameView.height - height - ySpeed || y + ySpeed <= 0) {
            ySpeed = -ySpeed
        }
        y = y + ySpeed
        currentFrameColumn = ++currentFrameColumn % bmpColumns
    }

    open fun onDraw(canvas: Canvas) {
        update()
        val srcX = currentFrameColumn * width
        val srcY = currentFrameRow * height
        //src = new Rect(srcX, srcY, srcX + width, srcY + height);
        //Rect dst = new Rect(x, y, x + width, y + height);
        src.left = srcX
        src.top = srcY
        src.right = srcX + width
        src.bottom = srcY + height
        dst.left = x
        dst.top = y
        dst.right = x + width
        dst.bottom = y + height
        canvas.drawBitmap(bmp, src, dst, null)
    }


    protected open fun getNextAnimationRow(): Int {
        return 0
    }

    protected open fun getNextAnimationColumn(): Int {
        return 0
    }

    open fun isCollition(x2: Float, y2: Float): Boolean {
        return (x2 > x && x2 < x + width && y2 > y && y2 < y + height)
    }

    open fun isCollition(sprite2: Sprite): Boolean {
        // Detects collision between two rectangles (sprites)
        return if (x < sprite2.x + sprite2.width && x + width > sprite2.x && y + height > sprite2.y
            && y < sprite2.y + sprite2.height) {
            true
        } else {
            false
        }
    }
}