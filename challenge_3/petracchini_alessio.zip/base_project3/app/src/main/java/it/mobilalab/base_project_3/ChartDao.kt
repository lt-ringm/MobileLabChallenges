package it.mobilalab.base_project_3

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ChartDao {
    @Insert
    fun insertAll(vararg charts: Chart)

    @Delete
    fun delete(chart: Chart)

    @Query("SELECT * FROM Chart")
    fun getAll(): List<Chart>
}