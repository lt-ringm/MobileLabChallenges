package it.mobilalab.base_project_3

import android.R.attr.x
import android.R.attr.y
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Black
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize


class MainActivity : ComponentActivity(), SensorEventListener {


    lateinit var gameView: GameView
    private var lastUpdate: Long = 0
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var x:Int = 5
    private var y:Int = 13

    override fun onCreate(savedInstanceState: Bundle?) {

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager;
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        super.onCreate(savedInstanceState)
        lastUpdate = System.currentTimeMillis();
        gameView = GameView(this, this, x, y)

        setContent {
            ShipItem()
        }
    }


    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun ShipItem(){
        var mExpanded by remember { mutableStateOf(false) }         // Declaring a boolean value to store the expanded state of the Text Field
        val mShips = listOf("asteroid", "pink_asteroid")
        var mSelectedText by remember { mutableStateOf("") }         // Create a string value to store the selected ship
        var mTextFieldSize by remember { mutableStateOf(Size.Zero)}

        val icon = if (mExpanded)           // Up Icon when expanded and down icon when collapsed
            Icons.Filled.KeyboardArrowUp
        else
            Icons.Filled.KeyboardArrowDown

        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // "Menu" TopAppBar
            CenterAlignedTopAppBar (
                title = { Text("Welcome!", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    titleContentColor = White,
                    containerColor = Color.Transparent
                    ),
                modifier = Modifier.padding(50.dp)
            )

            CenterAlignedTopAppBar (
                title = { Text("Choose your ship:", fontSize = 20.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = White
                ),
                modifier = Modifier.padding(15.dp)
            )

            // Create an Outlined Text Field with icon and not expanded
            OutlinedTextField(
                value = mSelectedText,
                onValueChange = { mSelectedText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates ->
                        // This value is used to assign to the DropDown the same width
                        mTextFieldSize = coordinates.size.toSize()
                    }
                    .padding(20.dp),
                label = {Text("ship name")},
                trailingIcon = {
                    Icon(icon,"contentDescription",
                        Modifier.clickable { mExpanded = !mExpanded })
                },
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = White,
                    unfocusedBorderColor = White,
                    cursorColor = White,
                    focusedLabelColor = White,
                    unfocusedLabelColor = White,
                    textColor = White)
            )

            // Create a drop-down menu with list of ships, when clicked, set the Text Field text as the ship selected
            DropdownMenu(
                expanded = mExpanded,
                onDismissRequest = { mExpanded = false },
                modifier = Modifier
                    .width(with(LocalDensity.current) { mTextFieldSize.width.toDp() })
                    .padding(50.dp)
            ) {
                mShips.forEach { label ->
                   DropdownMenuItem(
                        text = { Text(text = label) },
                        onClick = {
                        mSelectedText = label
                        mExpanded = false
                        },
                        leadingIcon = @Composable {showImage(name = label)}
                    )
                }
            }

            Button(
                onClick = {
                    if (mSelectedText == "") {
                        Toast.makeText(this@MainActivity,"Default ship will be used!", Toast.LENGTH_SHORT).show()
                        Thread.sleep(2_000)  // wait for 1 second
                        gameView.shipName = mSelectedText
                        setContentView(gameView)
                    }
                    else{
                        gameView.shipName = mSelectedText
                        setContentView(gameView)
                    } },
                modifier = Modifier
                    .padding(60.dp)
                    .height(50.dp)
                    .width(100.dp),
                colors = ButtonDefaults.buttonColors(White)
            ) {
                Text("Play!", color = Black)
            }
        }
    }

    @Preview
    @Composable
    fun PreviewShipCard() {
        ShipItem()
    }


    @Composable
    fun showImage(name: String) {
        val drawableResourceId =
            this.resources.getIdentifier(name, "drawable", this.packageName)
        Image(
            painter = painterResource(id = drawableResourceId),
            contentDescription = "")
    }

    public override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this);
        gameView.pauseMusicPlayer()
    }

    public override fun onResume() {
        super.onResume()
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        gameView.startMusicPlayer()
    }

    public override fun onDestroy() {
        super.onDestroy()
        gameView.stopMusicPlayer()
        gameView.releaseMusicPlayer()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val millibarsOfPressure = event!!.values[0]
        if (event.sensor.getType() === Sensor.TYPE_ACCELEROMETER) {
            x = event.values[0].toInt()
            y = event.values[1].toInt()
        }
    }

    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
        Log.v("success","yes")
    }

}


