package it.space_invaders_kotlin

import android.graphics.Bitmap
import it.mobilalab.base_project_3.GameView
import it.mobilalab.base_project_3.Sprite

class Shoot(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x: Int,
    y: Int,
    xSpeed: Int,
    invaderShoot: Boolean,
    alive: Boolean
): Sprite(gameView, bmp, bmpRows, bmpColumns) {

    private var invaderShoot: Boolean

    init {
        this.x = x
        this.y = y
        this.invaderShoot = invaderShoot
        this.xSpeed = xSpeed
        this.ySpeed = if (invaderShoot) 25 else -35
        this.alive = alive
    }

    override fun update() {
        if (x >= gameView.width - width - xSpeed || x + xSpeed <= 0) {
            alive = false
        } else {
            x = x + xSpeed
        }
        if (y >= gameView.height - height - ySpeed || y + ySpeed <= 0) {
            alive = false
        } else {
            y = y + ySpeed
        }
        currentFrameColumn = getNextAnimationColumn()
    }

    override fun getNextAnimationRow(): Int {
        return 0
    }

    override fun getNextAnimationColumn(): Int {
        return ++currentFrameColumn % bmpColumns
    }
}