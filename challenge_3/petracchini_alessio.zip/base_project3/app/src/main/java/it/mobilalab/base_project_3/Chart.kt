package it.mobilalab.base_project_3

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Chart(@PrimaryKey val udi: Int,
                 @ColumnInfo(name = "username") val username: String?,
                 @ColumnInfo(name = "score") val score: String?,) {
}