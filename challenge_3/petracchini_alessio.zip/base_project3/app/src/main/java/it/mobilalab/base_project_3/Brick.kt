package it.mobilalab.base_project_3

import android.graphics.Bitmap

class Brick(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x: Int,
    y: Int
): Sprite(gameView, bmp, bmpRows, bmpColumns) {

    init {
        this.x = x
        this.y = y
        this.alive = true
    }

    override fun update() {}

    override fun getNextAnimationRow(): Int {
        return 0
    }

    override fun getNextAnimationColumn(): Int {
        return 0
    }

}