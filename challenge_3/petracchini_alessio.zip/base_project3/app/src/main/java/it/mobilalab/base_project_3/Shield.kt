package it.mobilalab.base_project_3

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas


class Shield(
    gameView: GameView,
    brickBmp: Bitmap,
    spriteColumns: Int,
    horizontalNumOfBrick: Int,
    verticalNumOfBrick: Int,
    y: Int,
    numberOfWalls: Int
) {

    var shield = arrayListOf<Wall>()
    var y = 0

    init {
        this.y = y
        for (i in 0 until numberOfWalls) {
            shield.add(
                Wall(
                    gameView,
                    brickBmp,
                    spriteColumns,
                    horizontalNumOfBrick,
                    verticalNumOfBrick
                )
            )
        }
    }

    @SuppressLint("WrongCall")
    fun onDraw(canvas: Canvas?) {
        for (wall in shield) {
            wall.onDraw(canvas)
        }
    }

    fun isAlive(): Boolean {
        return shield.size != 0
    }
}