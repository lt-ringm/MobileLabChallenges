package it.mobilalab.base_project_3

import android.graphics.Bitmap

open class InvaderSpaceShip(
    gameView: GameView,
    bmp: Bitmap,
    spriteRows: Int,
    spriteColumns: Int,
    x: Int,
    y: Int,
    points: Int
): Sprite(gameView, bmp, spriteRows, spriteColumns) {

    var points = 0

    init {
        //Depends on each type of sprite
        this.x = x
        this.y = y
        this.xSpeed = 0
        this.ySpeed = 0
        this.points = points
    }

    override fun update() {
        if (x >= gameView.width - width - xSpeed || x + xSpeed <= 0) {
        } else {
            x = x + xSpeed
        }
        currentFrameColumn = getNextAnimationColumn()
    }

    override fun getNextAnimationRow(): Int {
        return 0
    }

    override fun getNextAnimationColumn(): Int {
        return ++currentFrameColumn % bmpColumns
    }

    open fun moveDown(stepDown: Int) {
        y = y + stepDown
    }

}
