package it.mobilalab.base_project_3

import android.R.attr
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import java.util.Random


class InvaderSpaceFleet(
    gameView: GameView,
    landingHeight: Int) {

    private var invaderSpaceShips: ArrayList<ArrayList<InvaderSpaceShip>>? = null
    private var gameView: GameView
    private var spaceBetweenRows = 25
    private val periodMotherShip = 600
    private var timerMotherShip = 600
    private var periodMoveDown = 200
    private var timerMoveDown = 200
    private val stepDown = 4
    private var motherShipList: List<InvaderSpaceShip>? = null
    private var lastDestroyedShipPoints = 0
    private var landingHeight = 0
    private var arrive = false
    private var bmpMotherShip: Bitmap
    private var bmpInvader_1: Bitmap
    private var bmpInvader_2: Bitmap
    private var numberOfShips = 0

    init {
        timerMoveDown = timerMoveDown / (2 * attr.level)
        periodMoveDown = periodMoveDown / (2 * attr.level)
        numberOfShips = if (attr.level <= 5) 2 + attr.level else 7

        this.gameView = gameView
        this.landingHeight = landingHeight
        bmpMotherShip = BitmapFactory.decodeResource(gameView.resources, R.drawable.mothership)
        bmpInvader_1 =
            BitmapFactory.decodeResource(gameView.resources, R.drawable.invaderspaceship_1)
        bmpInvader_2 =
            BitmapFactory.decodeResource(gameView.resources, R.drawable.invaderspaceship_2)

        invaderSpaceShips = ArrayList()
        (invaderSpaceShips as ArrayList<List<InvaderSpaceShip>>)
            .add(createInvaderSpaceFleetRow(0, bmpInvader_2, 1, 2, numberOfShips, 200)!!)
        (invaderSpaceShips as ArrayList<List<InvaderSpaceShip>>).add(
            createInvaderSpaceFleetRow(
                1,
                bmpInvader_1,
                1,
                15,
                numberOfShips - 1,
                100
            )!!
        )
        createInvaderSpaceFleetRow(2, bmpInvader_2, 1, 2, numberOfShips, 50)?.let {
            (invaderSpaceShips as ArrayList<List<InvaderSpaceShip>>).add(
                it
            )
        }
        (invaderSpaceShips as ArrayList<List<InvaderSpaceShip>>).add(
            createInvaderSpaceFleetRow(
                3,
                bmpInvader_1,
                1,
                15,
                numberOfShips - 1,
                25
            )!!
        )
    }

    fun getInvaderSpaceShips(): List<List<InvaderSpaceShip?>?>? {
        return invaderSpaceShips
    }

    fun setInvaderSpaceShips(invaderSpaceShips: List<List<InvaderSpaceShip?>?>?) {
        this.invaderSpaceShips =
            invaderSpaceShips as ArrayList<java.util.ArrayList<InvaderSpaceShip>>?
    }

    fun onDraw(canvas: Canvas?) {
        for (fleetRow in invaderSpaceShips!!) {
            for (sprite in fleetRow) {
                if (canvas != null) {
                    sprite.onDraw(canvas)
                }
            }
        }

        //Timers
        timerMotherShip = timerMotherShip - 1
        timerMoveDown = timerMoveDown - 1
        if (timerMotherShip == 0) {
            if (!invaderSpaceShips!!.contains(motherShipList!!)) {
                createMotherShip()
            } else {
                timerMotherShip = periodMotherShip
            }
        }
        if (timerMoveDown == 0) {
            moveDown()
            timerMoveDown = periodMoveDown
        }
    }

    private fun moveDown() {
        for (fleetRow in invaderSpaceShips!!) {
            for (sprite in fleetRow) {
                sprite.moveDown(stepDown)
                if (sprite.y > landingHeight) {
                    arrive = true
                }
            }
        }
    }

    // Creates an invader space fleet
    private fun createInvaderSpaceFleetRow(
        fleetRow: Int,
        bmp: Bitmap,
        spriteRows: Int,
        spriteColumns: Int,
        numberOfShips: Int,
        points: Int
    ): List<InvaderSpaceShip>? {
        val row = ArrayList<InvaderSpaceShip>()
        val shipWidth = bmp.width / spriteColumns
        val dx = (gameView.width - shipWidth) / (numberOfShips - 1)
        var x = 0
        val y = spaceBetweenRows
        for (i in 0 until numberOfShips) {
            row.add(createInvaderSpaceShip(bmp, spriteRows, spriteColumns, x, y, points))
            x = x + dx
        }
        spaceBetweenRows = spaceBetweenRows + bmp.height
        return row
    }

    // Creates an invader ship
    private fun createInvaderSpaceShip(
        bmp: Bitmap,
        spriteRows: Int,
        spriteColumns: Int,
        x: Int,
        y: Int,
        points: Int
    ): InvaderSpaceShip {
        return InvaderSpaceShip(gameView, bmp, spriteRows, spriteColumns, x, y, points)
    }

    // Create a motherShip
    fun createMotherShip() {
        val spriteRows = 1
        val spriteColumns = 2
        val x = 0
        val y = 0
        val xSpeed = 15
        val ySpeed = 0
        motherShipList = ArrayList()
        val motherShip: InvaderSpaceShip = MotherShip(
            gameView,
            bmpMotherShip,
            spriteRows,
            spriteColumns,
            x,
            y,
            xSpeed,
            ySpeed,
            300
        )
        (motherShipList as ArrayList<InvaderSpaceShip>).add(motherShip)
        invaderSpaceShips?.add(motherShipList as ArrayList<InvaderSpaceShip>)

        //Initiate timer
        timerMotherShip = periodMotherShip
    }

    fun invaderArrive(): Boolean {
        return arrive
    }

    fun allInvadersDestroyed(): Boolean {
        var allDestroyed = false
        if (invaderSpaceShips!!.size == 0) {
            allDestroyed = true
        }
        return allDestroyed
    }

    fun getShooter(): Sprite? {
        val rnd = Random()
        val shooterRow = 0 //rnd.nextInt(invaderSpaceShips.size());
        val shooterCol: Int = rnd.nextInt(invaderSpaceShips!![shooterRow].size)
        return invaderSpaceShips!![shooterRow][shooterCol]
    }

    fun isCollision(goodSpaceShipShoot: Sprite?): Boolean {
        for (fleetRow in invaderSpaceShips!!) {
            for (sprite in fleetRow) {
                if (goodSpaceShipShoot?.let { sprite.isCollition(it) } == true) {
                    // Delete Sprite
                    lastDestroyedShipPoints = sprite.points
                    fleetRow.remove(sprite)

                    // If row is empty, delete row too
                    if (fleetRow.size == 0) {
                        invaderSpaceShips!!.remove(fleetRow)
                    }
                    return true
                }
            }
        }
        return false
    }

    fun getPoints(): Int {
        return lastDestroyedShipPoints
    }

}