package it.mobilalab.base_project_3

import android.graphics.Bitmap

class Explosion(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x: Int,
    y: Int,
    alive: Boolean
): Sprite(gameView, bmp, bmpRows, bmpColumns) {

    private var life = bmpRows

    init {
        this.alive = alive
        this.x = x
        this.y = y
    }

    override fun update() {
        if (--life < 1) {
            alive = false
        } else {
            currentFrameColumn = getNextAnimationColumn()
        }
    }

    override fun getNextAnimationRow(): Int {
        return 0
    }

    override fun getNextAnimationColumn(): Int {
        return ++currentFrameColumn % bmpColumns
    }

}