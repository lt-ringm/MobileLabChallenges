package it.mobilalab.base_project_3

import android.annotation.SuppressLint
import android.graphics.Canvas

class GameLoopThread(gameView: GameView): Thread() {

    private var view: GameView
    private var running = false

    init {
        this.view = gameView
    }

    fun setRunning(run: Boolean) {
        running = run
    }

    fun isRunning(): Boolean {
        return running
    }

    @SuppressLint("WrongCall")
    override fun run() {
        val ticksPS: Long = 1000 / FPS
        var startTime: Long
        var sleepTime: Long
        while (running) {
            var c: Canvas? = null
            startTime = System.currentTimeMillis()
            try {
                c = view.holder.lockCanvas()
                synchronized(view.holder) { view.onDraw(c) }
            } finally {
                if (c != null) {
                    view.holder.unlockCanvasAndPost(c)
                }
            }
            sleepTime = ticksPS - (System.currentTimeMillis() - startTime)
            try {
                if (sleepTime > 0) sleep(sleepTime) else sleep(10)
            } catch (e: Exception) {
            }
        }
    }

    companion object {
        val FPS: Long = 25
    }
}