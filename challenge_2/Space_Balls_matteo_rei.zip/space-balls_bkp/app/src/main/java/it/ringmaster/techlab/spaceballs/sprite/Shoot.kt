package it.ringmaster.techlab.spaceballs.sprite;

import android.graphics.Bitmap;
import it.ringmaster.techlab.spaceballs.GameView


class Shoot(
        gameView: GameView,
        bmp: Bitmap,
        bmpRows: Int,
        bmpColumns: Int,
        x: Int,
        y: Int,
        xSpeed: Int,
        invaderShoot: Boolean,
        alive: Boolean,
        currentFrameColumn: Int
): Sprite(gameView, bmp, bmpRows, bmpColumns, x, y, xSpeed, if (invaderShoot) 25 else -35, currentFrameColumn)
{

        var invaderShoot: Boolean
        var alive: Boolean
        init {
                this.invaderShoot = invaderShoot
                this.alive = alive
        }


}
