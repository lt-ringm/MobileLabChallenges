package it.ringmaster.techlab.spaceballs

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import it.ringmaster.techlab.spaceballs.sprite.Spaceship

class GameView(context: Context, activity: ComponentActivity) : SurfaceView(context) {

    lateinit var shipName: String
    private var activity: ComponentActivity
    private var context: Context
    private var shipSprite: Spaceship

    init {
        this.activity = activity
        this.context = context
        var bitmapShip = BitmapFactory.decodeResource(resources, R.drawable.otter_space)
        this.shipSprite = Spaceship(this, bitmapShip, 100, 100, 10)

        holder.addCallback(object: SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                activity.setContent { readyToPlay() }
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                //TODO: implement
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            }
        })
    }

    @OptIn(ExperimentalMaterial3Api::class, ExperimentalTextApi::class)
    @Composable
    fun readyToPlay() {

        Row {
            Text(
                text = "YOU ARE NOW READY TO FIGHT...\nMAY THE FORCE BE WITH YOU!",
                fontSize = 30.sp,
                style = TextStyle(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFA932E4), Color(0xFFFFFFFF)
                        )
                    )
                ),
                modifier = Modifier.padding(top = 200.dp)
            )
        }
    }

    public override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
//        canvas.drawBitmap(shipSprite, )
    }
}