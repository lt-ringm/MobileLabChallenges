package it.ringmaster.techlab.spaceballs.sprite;

import android.graphics.Bitmap;
import it.ringmaster.techlab.spaceballs.GameView

open class Sprite(
    gameView: GameView,
    bmp: Bitmap,
    rows: Int,
    columns: Int,
    x: Int,
    y: Int,
    xSpeed: Int,
    ySpeed: Int,
    currentFrameColumn: Int
) {
    protected var bmpRows = 1
    protected var bmpColumns = 1
    protected var bmp: Bitmap
    protected var gameView: GameView
    protected var x: Int
    protected var y: Int
    protected var xSpeed: Int
    protected var ySpeed: Int
    protected var currentFrameColumn: Int

    var width = 0
    var height = 0

    init {
        this.bmpRows = rows
        this.bmpColumns = columns

        width = bmp.width / bmpColumns
        height = bmp.height / bmpRows
        this.bmp = bmp
        this.gameView = gameView
        this.x = x
        this.y = y
        this.xSpeed = xSpeed
        this.ySpeed = ySpeed
        this.currentFrameColumn = currentFrameColumn
    }


    protected open fun update(){
        if (x >= gameView.width - width - xSpeed || x + xSpeed <= 0 ) {
                xSpeed = -xSpeed
        }
        x = x + xSpeed
        if (y >= gameView.height - height - ySpeed || y + ySpeed <= 0) {
                ySpeed = -ySpeed
        }
        y = y + ySpeed
        currentFrameColumn = ++currentFrameColumn % bmpColumns
    }

}
