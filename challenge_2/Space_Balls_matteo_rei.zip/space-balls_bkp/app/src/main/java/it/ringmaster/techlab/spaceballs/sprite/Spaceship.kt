package it.ringmaster.techlab.spaceballs.sprite

import android.graphics.Bitmap
import it.ringmaster.techlab.spaceballs.GameView

class Spaceship(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    currentFrameColumn: Int
) : Sprite(gameView, bmp, bmpRows, bmpColumns, 0, 0,0, 0, currentFrameColumn)
{

    init {
        this.x = 0
        this.y = 1601
        this.ySpeed = 0
        this.xSpeed = 1
    }

}