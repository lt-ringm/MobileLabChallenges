package it.ringmaster.techlab.spaceballs

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import it.ringmaster.techlab.spaceballs.ui.theme.SpaceBallsTheme

class MainActivity : ComponentActivity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameView = GameView(this, this)

        setContent {
            SpaceBallsTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Space Baller")
//                    ChooseSpaceship()
                    ShipItem()
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun ShipItem(){
        var mExpanded by remember { mutableStateOf(false) }             // Declaring a boolean value to store the expanded state of the Text Field
        val mShips = listOf("asteroid", "pink_asteroid", "otter_space")
//        val mShips = listOf(
//            Spaceship("Spaceship 1", R.drawable.asteroid),
//            Spaceship("Spaceship 2", R.drawable.pink_asteroid),
//            Spaceship("Spaceship 3", R.drawable.otter_space)
//        )
        var mSelectedText by remember { mutableStateOf("") }            // Create a string value to store the selected ship
        var mTextFieldSize by remember { mutableStateOf(Size.Zero) }

        val icon = if (mExpanded)           // Up/Down Icon
            Icons.Filled.KeyboardArrowUp
        else
            Icons.Filled.KeyboardArrowDown

        Column(
            Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // "Menu" TopAppBar
            CenterAlignedTopAppBar (
                title = { Text("Welcome!", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    titleContentColor = Color.White,
                    containerColor = Color.Transparent
                ),
                modifier = Modifier.padding(50.dp)
            )

            CenterAlignedTopAppBar (
                title = { Text("Choose your ship:", fontSize = 20.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    titleContentColor = Color.White,
                    containerColor = Color.Transparent
                ),
                modifier = Modifier.padding(15.dp)
            )

            // Create an Outlined Text Field with icon and not expanded
            OutlinedTextField(
                value = mSelectedText,
                onValueChange = { mSelectedText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates ->
                        // This value is used to assign to the DropDown the same width
                        mTextFieldSize = coordinates.size.toSize()
                    }
                    .padding(20.dp),
                label = {Text("Ship name")},
                trailingIcon = {
                    Icon(icon,"contentDescription",
                        Modifier.clickable { mExpanded = !mExpanded })
                },
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    textColor = Color.White
                )
            )

            // Create a drop-down menu with list of ships, when clicked, set the Text Field text as the ship selected
            DropdownMenu(
                expanded = mExpanded,
                onDismissRequest = { mExpanded = false },
                modifier = Modifier
                    .width(with(LocalDensity.current) { mTextFieldSize.width.toDp() })
                    .padding(50.dp)
            ) {
                mShips.forEach { label ->
                    DropdownMenuItem(
                        text = { Text(text = label) },
                        onClick = {
                            mSelectedText = label
                            mExpanded = false
                        },
                        leadingIcon = @Composable {showImage(name = label)}
                    )
                }
            }

            Button(
                onClick = {
                    if (mSelectedText == "") {
                        Toast.makeText(this@MainActivity,"Default ship will be used!", Toast.LENGTH_SHORT).show()
                        Thread.sleep(1_000)  // wait for 1 second
                        gameView.shipName = mSelectedText
                        setContentView(gameView)
                    }
                    else{
                        gameView = GameView(context = this@MainActivity,
                            this@MainActivity)
                        gameView.shipName = mSelectedText
                        setContentView(gameView)
                    } },
                modifier = Modifier
                    .padding(60.dp)
                    .height(50.dp)
                    .width(100.dp),
                colors = ButtonDefaults.buttonColors(Color.White)
            ) {
                Text("Play!", color = Color.Black)
            }
        }
    }

    @Preview
    @Composable
    fun PreviewShipCard() {
        ShipItem()
    }


    @Composable
    fun showImage(name: String) {
        val drawableResourceId =
            this.resources.getIdentifier(name, "drawable", this.packageName)
        Image(
            painter = painterResource(id = drawableResourceId),
            contentDescription = "")
    }

    override public fun onPause() {
        super.onPause()
    }

    override public fun onResume() {
        super.onResume()
    }

    override public fun onDestroy() {
        super.onDestroy()
    }

}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    SpaceBallsTheme {
        Greeting("Space Rebel")
    }
}

//
//@Preview(showBackground = true)
//@Composable
//fun ChooseSpaceship() {
//    val shipList = arrayOf(
//        Spaceship("Spaceship 1", R.drawable.asteroid),
//        Spaceship("Spaceship 2", R.drawable.icon),
//        Spaceship("Spaceship 3", R.drawable.pink_asteroid)
//    )
//
//    // state of the menu
//    var expanded by remember {
//        mutableStateOf(false)
//    }
//    var shipChoosed: Spaceship
//
////    Box(contentAlignment = Alignment.Center) {
//    Box() {
//        // 3 vertical dots icon
//        IconButton(onClick = {
//            expanded = true
//        }) {
//            Icon(
//                imageVector = Icons.Default.MoreVert,
//                contentDescription = "Choose spaceship"
//            )
//        }
//
//        DropdownMenu(
//            expanded = expanded,
//            onDismissRequest = { expanded = false }
//        ) {
//            //adding items
//            shipList.forEachIndexed { itemIndex, itemValue ->
//                DropdownMenuItem(
//                    text = { Text(text = itemValue.name) },
//                    onClick = {
//                        shipChoosed = itemValue
//                        expanded = false },
//                    leadingIcon = { Icon(painter = painterResource(id = itemValue.iconId), contentDescription = stringResource(id = itemValue.iconId))}
//                )
//            }
//        }
//    }
//
//}

//data class Spaceship(val name: String, val iconId: Int) {}

