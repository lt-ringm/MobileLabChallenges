package it.mobilelab.challenge_1

import android.graphics.Bitmap

open class Sprite (
    gameview:GameView,
    bmp:Bitmap,
    n_rows:Int,
    n_columns:Int,
    ){

    protected var bmpRows = 1
    protected var bmpColumns = 1
    protected var bmp: Bitmap

    var width = 0
    var height = 0

    init{
        this.bmpRows = n_rows
        this.bmpColumns = n_columns
        width = bmp.width / bmpColumns
        height = bmp.height / bmpRows
        this.bmp = bmp

    }

    protected open fun update(){

    }

}