package it.mobilelab.challenge_1

import android.graphics.Bitmap

class Spaceship(
    gameView: GameView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x:Int,
    y:Int,
    xSpeed : Int,
    invaderShoot: Boolean,
    alive: Boolean
):Sprite(gameView,bmp,bmpRows,bmpColumns) {

    protected var x:Int
    protected var y:Int
    protected var xSpeed : Int
    protected var ySpeed : Int
    protected var invaderShoot: Boolean
    protected var alive: Boolean

    init{
        this.x= x
        this.y = y
        this.invaderShoot = invaderShoot
        this.xSpeed = xSpeed
        this.ySpeed = if(invaderShoot) 25  else -35
        this.alive = alive
    }




}