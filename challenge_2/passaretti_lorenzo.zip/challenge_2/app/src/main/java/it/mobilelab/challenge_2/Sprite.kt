package com.example.challenge_1

import android.graphics.Bitmap
import android.view.SurfaceView

open class Sprite (view: SurfaceView, bmp: Bitmap, bmpRows: Int, bmpColumns: Int) {
    var bmp: Bitmap
    var bmpRows = 1
    var bmpColumns = 1
    var width = 0
    var height = 0

    init {
        this.bmp = bmp
        this.bmpRows = bmpRows
        this.bmpColumns = bmpColumns
        width = bmp.width / bmpColumns
        height = bmp.height / bmpRows
    }

    open fun moveRight() {
    }
    open fun moveLeft() {
    }
    open fun moveUp() {
    }
    open fun moveDown() {
    }
}