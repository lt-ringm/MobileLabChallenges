package com.example.challenge_1

import android.graphics.Bitmap
import android.view.SurfaceView

class Spaceship (
    view: SurfaceView,
    bmp: Bitmap,
    bmpRows: Int,
    bmpColumns: Int,
    x: Int,
    y: Int,
    xSpeed: Int,
    ySpeed: Int,
    ): Sprite( view, bmp, bmpRows, bmpColumns) {
    var xSpeed: Int
    var ySpeed: Int
    var y: Int
    var x: Int
    var view: SurfaceView

    init {
        this.x = x
        this.y = y
        this.xSpeed = xSpeed
        this.ySpeed = ySpeed
        this.view = view
    }

    override fun moveRight() {
        if (x < view.width - width - xSpeed && x + xSpeed > 0) {
            x += xSpeed
        }
    }

    override fun moveLeft() {
        if (x < view.width - width - xSpeed && x + xSpeed > 0) {
            x -= xSpeed
        }
    }

    override fun moveUp() {
        if (y < view.height - height - ySpeed && y + ySpeed > 0) {
            y += ySpeed
        }
    }
    override fun moveDown() {
        if (y < view.height - height - ySpeed && y + ySpeed > 0) {
            y -= ySpeed
        }
    }

}